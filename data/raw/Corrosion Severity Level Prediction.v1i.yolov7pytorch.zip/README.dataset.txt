# Corrosion Severity Level Prediction > 2026-01-03 6:39pm
https://universe.roboflow.com/el-a1cwo/corrosion-severity-level-prediction-swtbk

Provided by a Roboflow user
License: CC BY 4.0

